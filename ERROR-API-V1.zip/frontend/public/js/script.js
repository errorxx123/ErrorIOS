async function createKey() {
    const res = await fetch('/api/keys/create', { method: 'POST' });
    const data = await res.json();
    alert('Key Created: ' + data.key);
}

async function listPackages() {
    const res = await fetch('/api/packages/list');
    const data = await res.json();
    alert('Packages: ' + JSON.stringify(data));
}
