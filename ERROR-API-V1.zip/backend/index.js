const express = require('express');
const app = express();
const keyRoutes = require('./routes/keys');
const packageRoutes = require('./routes/packages');
app.use(express.json());
app.use('/api/keys', keyRoutes);
app.use('/api/packages', packageRoutes);
app.listen(3000, () => console.log('API Server running on port 3000'));
