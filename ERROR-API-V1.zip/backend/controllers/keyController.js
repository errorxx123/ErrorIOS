const fs = require('fs');
const path = './database/keys.json';
let keys = require('../../database/keys.json');

function saveKeys() {
    fs.writeFileSync(path, JSON.stringify(keys, null, 2));
}

exports.createKey = (req, res) => {
    const newKey = { key: Math.random().toString(36).substring(2, 15), status: 'active' };
    keys.push(newKey);
    saveKeys();
    res.json(newKey);
};

exports.verifyKey = (req, res) => {
    const found = keys.find(k => k.key === req.params.key);
    res.json({ valid: !!found && found.status === 'active' });
};

exports.lockKey = (req, res) => {
    const key = keys.find(k => k.key === req.body.key);
    if (key) key.status = 'locked';
    saveKeys();
    res.json({ success: true });
};

exports.deleteKey = (req, res) => {
    keys = keys.filter(k => k.key !== req.body.key);
    saveKeys();
    res.json({ success: true });
};
