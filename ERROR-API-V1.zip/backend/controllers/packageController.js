const fs = require('fs');
const path = './database/packages.json';
let packages = require('../../database/packages.json');

function savePackages() {
    fs.writeFileSync(path, JSON.stringify(packages, null, 2));
}

exports.createPackage = (req, res) => {
    const newPackage = { name: req.body.name };
    packages.push(newPackage);
    savePackages();
    res.json(newPackage);
};

exports.listPackages = (req, res) => {
    res.json(packages);
};
