const express = require('express');
const router = express.Router();
const { createKey, verifyKey, lockKey, deleteKey } = require('../controllers/keyController');

router.post('/create', createKey);
router.get('/verify/:key', verifyKey);
router.post('/lock', lockKey);
router.post('/delete', deleteKey);

module.exports = router;
