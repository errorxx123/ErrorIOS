const express = require('express');
const router = express.Router();
const { createPackage, listPackages } = require('../controllers/packageController');

router.post('/create', createPackage);
router.get('/list', listPackages);

module.exports = router;
